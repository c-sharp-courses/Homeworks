﻿using System;

namespace Homeworks
{
    public class Class1
    {
    }
}
